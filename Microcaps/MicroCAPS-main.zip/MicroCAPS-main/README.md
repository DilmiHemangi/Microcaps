# MicroCAPS
Micro Cars Assembling and Production System by -- GROUP CS03 --

# SCS2201/2202 Group Project I
This is for our second year group project

