<!-- FOOTER FILE FOR ALL SUPERVISOR PAGES -->

    <!-- <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.min.js"></script> -->

    <script type="text/javascript" src="<?php echo URL_ROOT; ?>public/javascripts/supervisorjs/main.js"></script>
    <script type="text/javascript" src="<?php echo URL_ROOT; ?>public/javascripts/supervisorjs/buttons.js"></script>
    <script type="text/javascript" src="<?php echo URL_ROOT; ?>public/javascripts/supervisorjs/events.js"></script>

</body>

</html>