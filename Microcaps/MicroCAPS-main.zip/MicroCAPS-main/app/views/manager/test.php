<?php require_once APP_ROOT . '\views\manager\includes\header.php'; ?>
<?php require_once APP_ROOT . '\views\manager\includes\navbar.php'; ?>

<?php

print_r($data)

?>

</div>
</div>

<script type="text/javascript" src="<?php echo URL_ROOT; ?>public/javascripts/main.js"></script>

<script type="text/javascript" src="<?php echo URL_ROOT; ?>public/javascripts/charts.js"></script>